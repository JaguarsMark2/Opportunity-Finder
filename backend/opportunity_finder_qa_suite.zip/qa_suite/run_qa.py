import json
from pathlib import Path

from report import Report
from api_smoke import run_api_checks
from ui_smoke import run_ui_checks


def main():
    cfg_path = Path(__file__).parent / "qa_config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    report = Report()

    run_api_checks(cfg, report)
    run_ui_checks(cfg, report)

    out = Path("qa_report.md")
    out.write_text(report.to_md(), encoding="utf-8")
    print(f"WROTE: {out.resolve()}")


if __name__ == "__main__":
    main()
